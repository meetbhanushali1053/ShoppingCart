from django.shortcuts import render, redirect
from django.contrib.auth.hashers import make_password
from store.models.customer import Customer
from django.views import View


class Forgot(View):
    def get(self, request):
        return render(request, 'forgot.html')

    def post(self, request):
        postData = request.POST
        email = postData.get('email')
        password = postData.get('password')
        # validation
        value = {
            'email': email
        }
        error_message = None

        customer = Customer(
                            email=email,
                            password=password)
        error_message = self.validateCustomer(customer)

        if not error_message:
            print( email, password)
            customer.password = make_password(customer.password)
            customer.register()
            return redirect('homepage')
        else:
            data = {
                'error': error_message,
                'values': value
            }
            return render(request, 'signup.html', data)

    def validateCustomer(self, customer):
        error_message = None;
        if (customer.email):
            error_message = "Email is Required !!"
        elif len(customer.password) < 6:
            error_message = 'Password must be 6 char long'
        elif not customer.isExists():
            error_message = 'Email Not Registered..'
        # saving

        return error_message
